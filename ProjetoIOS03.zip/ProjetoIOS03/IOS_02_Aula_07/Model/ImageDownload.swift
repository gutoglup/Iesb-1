//
//  ImageDownload.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 06/06/18.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireImage

class Image{
    func download(url : String) -> UIImage?{
        var imagemBaixada : UIImage?
        
        Alamofire.request("https://httpbin.org/image/png").responseImage { response in
            
            if let image = response.result.value {
                imagemBaixada = image
            }
        }
        return imagemBaixada
    }
}
