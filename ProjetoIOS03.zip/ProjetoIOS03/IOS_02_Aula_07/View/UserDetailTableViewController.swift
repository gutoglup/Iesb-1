//
//  UserDetailTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 23/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class UserDetailTableViewController: UITableViewController {

    var user : UserCodable?

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return 10
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // verificação do numero da celula
        if indexPath.row > 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "albumCell", for: indexPath) as! AlbumTableViewCell
            // retorno da celular configurada para o tableView
            return cell
        }else{
            print("To aqui 0 ®")
            let cell = tableView.dequeueReusableCell(withIdentifier: "userDetailCell", for: indexPath) as! UserDetailTableViewCell
            if let user = user {
                cell.config(user: user)                
            }
            // retorno da celular configurada para o tableView
            return cell
        }
    }
    

}
