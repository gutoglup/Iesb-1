//
//  UserDetailTableViewCell.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 30/05/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class UserDetailTableViewCell: UITableViewCell {
    
    // Pré-Link Outlet
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var emaillabel: UILabel!
    @IBOutlet weak var webSiteLabe: UILabel!
    
    var blockToPerform: ((UIViewController) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func AlterarFotoDePerfil(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self 
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        
        blockToPerform?(picker)
    }
    
    func config(user : UserCodable){
        self.emaillabel.text = user.email
        self.webSiteLabe.text = user.website
    }
    
}
extension UserDetailTableViewCell : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image = info[UIImagePickerControllerEditedImage]
        self.userImage.image = image as? UIImage
        
        picker.dismiss(animated: true, completion: nil)
    }
}
