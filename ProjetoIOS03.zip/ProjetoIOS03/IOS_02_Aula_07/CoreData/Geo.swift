//
//  Geo.swift
//  ExemploTableView
//
//  Created by leonardo on 04/04/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Geo: NSManagedObject {

    static func insertOrUpdate(_ geo: CodableGeo, inContext context: NSManagedObjectContext) -> Geo {
        let geoCoredata = Geo(context: context)
        geoCoredata.lat = geo.lat
        geoCoredata.lng = geo.lng
        return geoCoredata
    }
}
