//
//  Adress.swift
//  ExemploTableView
//
//  Created by leonardo on 04/04/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Address: NSManagedObject {

    static func insertOrUpdate(_ address: CodableAddress, inContext context: NSManagedObjectContext) -> Address {
        let addressCoredata = Address(context: context)
        addressCoredata.street = address.street
        addressCoredata.suite = address.suite
        addressCoredata.city = address.city
        addressCoredata.zipcode = address.zipcode
        
        let geo = Geo.insertOrUpdate(address.geo, inContext: context)
        addressCoredata.geo = geo
        return addressCoredata
    }
    
}
