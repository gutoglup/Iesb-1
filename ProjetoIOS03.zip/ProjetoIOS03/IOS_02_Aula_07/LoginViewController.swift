//
//  LoginViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 06/06/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import FirebaseAuth
import FBSDKLoginKit
import GoogleSignIn
class LoginTableViewController: UITableViewController, GIDSignInUIDelegate {
    
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var senhaLabel: UITextField!
    @IBOutlet weak var facebookLoginButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        let loginButton = FBSDKLoginButton()
        view.addSubview(loginButton)
        loginButton.delegate = self
    }
    @IBAction func loginComFacebook(_ sender: UIButton) {
        FBSDKLoginManager().logIn(withReadPermissions: ["email","public_profile"], from: self){ (result,error) in
            if error != nil {
                print("falha")
            }
            if result != nil {
                print(result?.token.tokenString)
            }
            
        }
    }
    @IBAction func loginComEmail(_ sender: UIButton) {
        if let email = emailLabel.text, let senha = senhaLabel.text {
            Auth.auth().signIn(withEmail: email, password: senha) { (user, error) in
                if error != nil {
                    print(error)
                    return
                }
                if user != nil{
                    print("deu certo")
                }
            }
        }
    }
    func registrarCredencial(credential : AuthCredential){
        Auth.auth().signInAndRetrieveData(with: credential){ (user, error) in
            if error != nil {
                print(error)
                return
            }
            if user != nil {
                print("deu certo")
            }
            
        }
    }
}

extension LoginTableViewController: FBSDKLoginButtonDelegate {
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if error != nil {
            print("Deu erro")
            return
        }
        
        let credential = FacebookAuthProvider.credential(withAccessToken: result.token.tokenString)
        self.registrarCredencial(credential: credential)
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("depois do log out")
    }
    
    
}
