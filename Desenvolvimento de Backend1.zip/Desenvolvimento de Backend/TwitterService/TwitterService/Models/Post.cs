﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterService.Models
{
    public class Post
    {
        public int Id_post { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Created_date { get; set; }
        public int Id_user { get; set; }
    }
}
