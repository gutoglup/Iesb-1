﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;

namespace TwitterService.Controllers
{
    [Route("api/[controller]")]
    public class PostController : Controller
    {
        // GET api/values
        [HttpGet]
        public String Get()
        {
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM users", conexao);
            MySqlDataReader result;
            try
            {

                conexao.Open();
            }
            catch (MySqlException ex)
            {
                return "deu ruim." + ex;
            }
            result = comando.ExecuteReader();
            while (result.Read())
            {
                return result["name"].ToString();

            }
            return "foi!";
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
            //conexao.Open();
            //MySqlCommand comm = conexao.CreateCommand();
            //comm.CommandText = "INSERT INTO users(name,email,is_active) VALUES(?name, ?email, ?is_active)";
            //comm.Parameters.Add("?name", "Myname");
            //comm.Parameters.Add("?email", "Myaddress");
            //comm.Parameters.Add("?is_active", "1");
            //comm.ExecuteNonQuery();
            //conexao.Close();
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
