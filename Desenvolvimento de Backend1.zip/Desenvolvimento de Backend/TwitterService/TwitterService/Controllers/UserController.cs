﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using TwitterService.Models;

namespace TwitterService.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {

        // GET api/user
        [HttpGet]
        public List<User> Get()
        {
            List<User> userList = new List<User>();
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM users", conexao);
            MySqlDataReader result;

            try
            {
                
                conexao.Open();
            }
            catch (MySqlException ex)
            {
                return userList;
            }
            result = comando.ExecuteReader();
            while (result.Read())
            {
               
                userList.Add(new User(result["id_user"].ToString(), 
                                      result["name"].ToString(), 
                                      result["email"].ToString(), 
                                      Convert.ToInt32(result["is_active"].ToString())));
                
            }
            return userList;
        }

        // GET api/user/5
        [HttpGet("{id}")]
        public List<User> Get(int id)
        {
            List<User> userList = new List<User>();
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            MySqlCommand query = new MySqlCommand("SELECT * FROM users Where id_user = @id_user", conexao);
            query.Parameters.AddWithValue("@id_user", id);
            MySqlDataReader result;

            try
            {
                conexao.Open();
                result = query.ExecuteReader();
            }
            catch (MySqlException ex)
            {
                return userList;
            }
            
            while (result.Read())
            {

                userList.Add(new User(result["id_user"].ToString(),
                                      result["name"].ToString(),
                                      result["email"].ToString(),
                                      Convert.ToInt32(result["is_active"].ToString())));

            }
            return userList;
        }

        // POST api/user
        [HttpPost]
        public ActionResult Post([FromBody] User usuario)
        {

            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            conexao.Open();
            MySqlCommand comm = conexao.CreateCommand();
            comm.CommandText = "INSERT INTO users(name,email,is_active) VALUES(?name, ?email, ?is_active)";
            comm.Parameters.Add("?name", usuario.Name.ToString());
            comm.Parameters.Add("?email", usuario.Email.ToString());
            comm.Parameters.Add("?is_active", usuario.Is_active.ToString());
            comm.ExecuteNonQuery();
            conexao.Close();

            return new ObjectResult(usuario);
        }

        // PUT api/user/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]User user)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
                conexao.Open();
                MySqlCommand comm = conexao.CreateCommand();
                comm.CommandText = "Update users set name = @name, email = @email , is_active = @is_active where id_user = @id_user";
                comm.Parameters.AddWithValue("@id_user", id);
                comm.Parameters.AddWithValue("@name", user.Name.ToString());
                comm.Parameters.AddWithValue("@email", user.Email.ToString());
                comm.Parameters.AddWithValue("@is_active", user.Is_active.ToString());
                comm.ExecuteNonQuery();
                conexao.Close();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        // DELETE api/user/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
                conexao.Open();
                MySqlCommand comm = conexao.CreateCommand();
                comm.CommandText = "Delete from users where id_user = @id_user";
                comm.Parameters.AddWithValue("@id_user", id); ;
                comm.ExecuteNonQuery();
                conexao.Close();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }
    }
}
