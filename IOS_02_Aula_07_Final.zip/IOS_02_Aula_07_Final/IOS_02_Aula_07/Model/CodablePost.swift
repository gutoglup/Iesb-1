//
//  CodablePost.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 09/05/18.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

struct CodablePost: Codable {
    
    var id: Int
    var userId: Int
    var title: String
    var body: String
    var user: UserCodable?
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId
        case title
        case body
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try values.decode(Int.self, forKey: .id)
        self.userId = try values.decode(Int.self, forKey: .userId)
        self.title = try values.decode(String.self, forKey: .title)
        self.body =  try values.decode(String.self, forKey: .body)
    }
    
    func encode(to encoder: Encoder) throws {
        var container =  encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(userId, forKey: .userId)
        try container.encode(title, forKey: .title)
        try container.encode(body, forKey: .body)
    }
    
}


struct LoadError: Error {
    var response: URLResponse?
}


struct PostLoader {
    
    static func loadPosts(withCompletion completion: @escaping ([CodablePost]?, Error?) -> Void) {
        URLSession.shared.dataTask(with: URL(string: "https://jsonplaceholder.typicode.com/posts")!) { (data, response, error) in
            guard error == nil else { completion(nil, error); return }
            guard data != nil else { completion(nil, LoadError(response: response)); return }
            guard let urlResponse = response as? HTTPURLResponse, urlResponse.statusCode == 200 else { completion(nil, LoadError(response: response)); return }
            
            do {
                let posts = try JSONDecoder().decode([CodablePost].self, from: data!)
                completion(posts, nil)
            }catch {
                completion(nil, error)
            }
            }.resume()
    }
    
}
