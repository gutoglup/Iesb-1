//
//  UsuariosTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 02/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class UsuariosTableViewController: UITableViewController {
    
    var users = [UserCodable]() {
        didSet {
            DispatchQueue.main.async(execute: self.tableView.reloadData)
            persist(users: users)
        }
    }
    var session : URLSession!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if Reachability()?.connection != Reachability.Connection.none {
            self.requestUsers()
        } else {
            //self.getUser()
        }
    }
    private func requestUsers() {
        session = URLSession(configuration: URLSession.shared.configuration, delegate: self, delegateQueue: nil)
        
        if let url = URL(string: "https://jsonplaceholder.typicode.com/users") {
            let request = URLRequest(url: url)
            session.dataTask(with: request).resume()
        }
    }
//    private func getUser() {
//        if let users = User.get(context: AppDelegate.persistentContainer.viewContext) {
//            var usersCodable = [UserCodable]()
//            for user in users {
//                UserCodable(id: user.id,
//                            name: user.name!,
//                            username: user.username!,
//                            email: user.email!,
//                            phone: user.phone!,
//                            website: user.website!,
//                            address: user.address?,
//                            company: user.company!)
//            }
//            self.users = usersCodable
//        }
//    }
    private func persist(users: [UserCodable]) {
        AppDelegate.persistentContainer.performBackgroundTask { (context) in
            for user in users {
                guard let userGravado = User.insertOrUpdate(user: user, inContext: context) else { break }
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return users.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell", for: indexPath) as! UsuarioTableViewCell
        let user = users[indexPath.row]
        cell.config(user: user)
        return cell
    }
}
extension UsuariosTableViewController: URLSessionDataDelegate {
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        do{
            let users = try JSONDecoder().decode([UserCodable].self, from: data)
            self.users = users
        }catch {
            print(error)
        }
    }
    func urlSession(_ session: URLSession, didBecomeInvalidWithError error: Error?) {
        if let error = error {
            print(error)
        }
    }
    
}
