//
//  FormTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 09/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class FormTableViewController: UITableViewController {
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var userNameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var streetLabel: UITextField!
    @IBOutlet weak var suiteLabel: UITextField!
    @IBOutlet weak var cityLabel: UITextField!
    @IBOutlet weak var zipCodeLabel: UITextField!
    @IBOutlet weak var latLabel: UITextField!
    @IBOutlet weak var lngLabel: UITextField!
    @IBOutlet weak var phoneLabel: UITextField!
    @IBOutlet weak var websiteLabel: UITextField!
    @IBOutlet weak var nameCompanyLabel: UITextField!
    @IBOutlet weak var catchPhrase: UITextField!
    @IBOutlet weak var bsLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        [nameLabel,
         userNameLabel,
         emailLabel,
         streetLabel,
         suiteLabel,
         cityLabel,
         zipCodeLabel,
         latLabel,
         lngLabel,
         phoneLabel,
         websiteLabel,
         nameCompanyLabel,
         catchPhrase,
         bsLabel].forEach({$0.delegate = self})
        
    }
    @IBAction func salvarButton(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func fecharModal(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    func enviar(){
        
    }
}
extension FormTableViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        switch textField {
            case nameLabel: userNameLabel.becomeFirstResponder()
            case userNameLabel: emailLabel.becomeFirstResponder()
            case emailLabel: phoneLabel.becomeFirstResponder()
            case phoneLabel: websiteLabel.becomeFirstResponder()
            case websiteLabel: streetLabel.becomeFirstResponder()
            case streetLabel: suiteLabel.becomeFirstResponder()
            case suiteLabel: cityLabel.becomeFirstResponder()
            case cityLabel: zipCodeLabel.becomeFirstResponder()
            case zipCodeLabel: latLabel.becomeFirstResponder()
            case latLabel: lngLabel.becomeFirstResponder()
            case lngLabel: nameCompanyLabel.becomeFirstResponder()
            case nameCompanyLabel: catchPhrase.becomeFirstResponder()
            case catchPhrase: bsLabel.becomeFirstResponder()
            case bsLabel: enviar()
            default: break
        }
        return true
    }
}
