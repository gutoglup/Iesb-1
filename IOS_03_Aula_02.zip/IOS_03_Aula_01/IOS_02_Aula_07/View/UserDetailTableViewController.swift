//
//  UserDetailTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 23/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class UserDetailTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {

        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return 0
    }

}
