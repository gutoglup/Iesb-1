//
//  User.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 02/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

struct UserCodable : Codable{
    var id: Int64
    var name: String
    var username: String
    var email: String
    var phone: String
    var website: String
    var address: CodableAddress
    var company: CodableCompany
    
    func UploadUser(user: UserCodable) {
        
        let url = URL(string: "https://jsonplaceholder.typicode.com/users")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let uploadData = try? JSONEncoder().encode(user) else {
            return
        }
        let task = URLSession.shared.uploadTask(with: request, from: uploadData) { data, response, error in
            if let error = error {
                print ("error: \(error)")
                return
            }
            
            guard let response = response as? HTTPURLResponse,
                (200...299).contains(response.statusCode) else {
                    print ("server error")
                    return
            }
        }
        
        task.resume()
    }
    
}

struct CodableAddress: Codable {
    
    var street: String
    var suite: String
    var city: String
    var zipcode: String
    var geo: CodableGeo
}

struct CodableGeo: Codable {
    
    var lat: String
    var lng: String
}

struct CodableCompany: Codable {
    
    var name: String
    var catchPhrase: String
    var bs: String
}

