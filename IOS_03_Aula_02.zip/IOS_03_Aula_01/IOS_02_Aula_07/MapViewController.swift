//
//  MapViewController.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 23/05/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
// protocolo para a passagem de infomações entres views

protocol MapViewControllerDelegate: class {
    func localizacaoSelecionada(coordenada: CLLocation)
}

class MapViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    weak var delegate: MapViewControllerDelegate?
    var pinAnnotation: MKPointAnnotation?
    let locationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // setter delegate
        locationManager.delegate = self
        // precisao da localização
        locationManager.desiredAccuracy = kCLLocationAccuracyKilometer
        // requerimento da localização
        locationManager.requestWhenInUseAuthorization()
        // inicio do monitoramento
        locationManager.startUpdatingLocation()
    }
    
    // MARK: - Salvar localização
    func salvarLocalizacao() {
        if let latitude = pinAnnotation?.coordinate.latitude, let longitude = pinAnnotation?.coordinate.longitude {
            let coordinate = CLLocation(latitude: latitude, longitude: longitude)
            delegate?.localizacaoSelecionada(coordenada: coordinate)
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    // MARK: - Indicar Localização
    @IBAction func marcarLocalizacao(_ gesture: UILongPressGestureRecognizer) {
        // remover Annotation já criado
        mapView.removeAnnotations(mapView.annotations)
        
        // pegar cooordenadas
        let point = gesture.location(in: mapView)
        let coordinate = mapView.convert(point, toCoordinateFrom: mapView)
        
        // criando e definindo propriedade de pinAnnotation
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "Endereço Selecionando"
        
        // setando annotation para uso na classe
        pinAnnotation = annotation
        
        // adicionando a tela
        mapView.addAnnotation(annotation)
    }


}

extension MapViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1]
        
        //verificação de validade da localização obtida
        if location.horizontalAccuracy > 0 {

            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            let region = MKCoordinateRegion(center: location.coordinate, span: span)
            
            // interrompendo o monitoramento
            locationManager.stopUpdatingLocation()
            
            // definindo localização inicial
            self.mapView.setRegion(region, animated: true)
        }
        
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("\(error)")
        print("Localização não encontrada!")
    }
}
