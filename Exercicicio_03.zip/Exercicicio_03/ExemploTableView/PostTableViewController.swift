//
//  PostTableViewController.swift
//  ExemploTableView
//
//  Created by Pedro Henrique on 28/03/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import UIKit

class PostTableViewController: UITableViewController {
    
    var usersArray = [UserCodable]()
    var posts: [CodablePost]? {
        didSet {
            DispatchQueue.main.async(execute: tableView.reloadData)
            persist(posts: self.posts, usersArray: self.usersArray)
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UserLoader.loadUser { [unowned self] (users, erro) in
            if let users = users {
                self.usersArray = users
            }
        }
        PostLoader.loadPosts { [unowned self]  (posts, error) in
            if let posts = posts {
                self.posts = posts
            }else{
                //self.getPost()
            }
        }
    }
    
    private func getPost() {
        if let posts = Post.get(context: AppDelegate.persistentContainer.viewContext) {
            var postsCodable = [CodablePost]()
            for post in posts {
               //postsCodable = CodablePost(id: post.id, title: post.title!, body: post.body!, user: post.user)
            }
            self.posts = postsCodable
        }
    }
    private func persist(posts: [CodablePost]?, usersArray: [UserCodable]) {
        AppDelegate.persistentContainer.performBackgroundTask { (context) in
            for post in posts! {
                let userFiltered = usersArray.filter{ $0.id == post.id }
                if let user = userFiltered.first {
                    var postFinal = post
                    postFinal.user = user
                    Post.insertOrUpdate(post: postFinal, inContext: context)
                }
            }
        }
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celulaPost", for: indexPath) as! PostViewCell
        guard let post = posts?[indexPath.row] else { return cell }
        cell.configurar(comPost: post)
        return cell
    }

    

}
