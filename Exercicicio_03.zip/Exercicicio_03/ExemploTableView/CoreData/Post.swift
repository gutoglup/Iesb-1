//
//  Post.swift
//  ExemploTableView
//
//  Created by Leonardo on 04/05/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Post: NSManagedObject {
    
    static func insertOrUpdate(post: CodablePost, inContext context: NSManagedObjectContext) -> Post {
        let postCoredata = Post(context: context)
        postCoredata.body = post.body
        postCoredata.id = Int64(post.id)
        postCoredata.title = post.title
        
        if let user = post.user {
            do {
                let userFetchRequest: NSFetchRequest<NSFetchRequestResult> = User.fetchRequest()
                userFetchRequest.predicate = NSPredicate(format: "id == %i", user.id)
                let usersResult = try context.fetch(userFetchRequest) as! [User]
                if !usersResult.isEmpty {
                    if let userCD = usersResult.first {
                        postCoredata.user = userCD
                    }
                } else {
                    let user = User.insertOrUpdate(user: user, inContext: context)
                    postCoredata.user = user
                }
            } catch {
                print(error)
            }
        }
        return postCoredata
    }
    
    static func get(context: NSManagedObjectContext) -> [Post]? {
        let posts: NSFetchRequest<Post> = self.fetchRequest()
        do {
            let result = try context.fetch(posts)
            return result
        } catch {
            print(error)
        }
        return nil
        
    }
    
    
}
