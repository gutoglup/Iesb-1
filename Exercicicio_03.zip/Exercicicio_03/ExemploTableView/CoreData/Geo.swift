//
//  Geo.swift
//  ExemploTableView
//
//  Created by Leonardo on 04/05/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Geo: NSManagedObject {

    static func insertOrUpdate(_ geo: CodableGeo, inContext context: NSManagedObjectContext) -> Geo {
        let geoCoredata = Geo(context: context)
        geoCoredata.lat = Double(geo.lat)!
        geoCoredata.lng = Double(geo.lng)!
        return geoCoredata
    }
}
