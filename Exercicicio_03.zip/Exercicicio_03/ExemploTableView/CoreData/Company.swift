//
//  Company.swift
//  ExemploTableView
//
//  Created by Leonardo on 04/05/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Company: NSManagedObject {

    static func insertOrUpdate(_ company: CodableCompany, inContext context: NSManagedObjectContext) -> Company {
        let companyCoredata = Company(context: context)
        companyCoredata.name = company.name
        companyCoredata.catchPhrase = company.catchPhrase
        companyCoredata.bs = company.bs
        return companyCoredata
    }
}
