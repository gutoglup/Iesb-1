//
//  User.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 02/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

struct UserCodable : Codable{
    var id: Int64
    var name: String
    var username: String
    var email: String
    var phone: String
    var website: String
    var address: CodableAddress
    var company: CodableCompany
}

struct CodableAddress: Codable {
    
    var street: String
    var suite: String
    var city: String
    var zipcode: String
    var geo: CodableGeo
}

struct CodableGeo: Codable {
    
    var lat: String
    var lng: String
}

struct CodableCompany: Codable {
    
    var name: String
    var catchPhrase: String
    var bs: String
}

struct UserLoader {
    
    static func loadUser(withCompletion completion: @escaping ([UserCodable]?, Error?) -> Void) {
        if let urlRequest = URL(string: "https://jsonplaceholder.typicode.com/users") {
            URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                guard error == nil else { completion(nil, error); return }
                guard let data = data else { completion(nil, LoadError(response: response)); return }
                guard let urlResponse = response as? HTTPURLResponse, urlResponse.statusCode == 200 else {
                    completion(nil, LoadError(response: response)); return
                }
                
                do {
                    let users = try JSONDecoder().decode([UserCodable].self, from: data)
                    completion(users, nil)
                } catch {
                    completion(nil, error)
                }
                
                }.resume()
            
        }
    }
}
