//
//  ViewController.swift
//  calculaitorBrainFinal
//
//  Created by leonardo on 04/04/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

    
    @IBOutlet weak var graphicButton: UIButton!
    @IBOutlet weak var displayLabel: UILabel!
    
    var calculatorBrain = CalculatorBrain()
    var expression : String = ""
    var usuerIsInMiddleOfTyping = false
    var displayValue: Double? {
        set {
            if let valor = newValue {
                displayLabel.text = String(valor)
            } else {
                displayLabel.text = "0"
            }
        }
        get {
            return Double(displayLabel.text!)!
        }
    }
    
    
    @IBAction func touchNumber(_ sender: UIButton) {
        if let digit = sender.titleLabel?.text {
            
            let currentValue = displayLabel.text
            
            if usuerIsInMiddleOfTyping {
                displayLabel.text = currentValue! + digit
            }else {
                displayLabel.text = digit
                usuerIsInMiddleOfTyping = true
            }
            
        }
    }
    @IBAction func performOperation(_ sender: UIButton) {
        let number = displayValue!
        calculatorBrain.setOperand(displayValue!)
        usuerIsInMiddleOfTyping = false
        if let symbol = sender.currentTitle {
            calculatorBrain.performOperation(symbol)
            displayValue = calculatorBrain.result
            if calculatorBrain.isUnary(symbol){
                expression = symbol.contains("x") ? symbol : "\(symbol) \(number)"
            }else{
                expression = ""
            }
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var destination: UIViewController? = segue.destination
        if let navCon = destination as? UINavigationController {
            destination = navCon.visibleViewController
        }
        if let identifier = segue.identifier{
            switch identifier {
            case "Graphic":
                if let graficoViewController = destination as? GraphicViewController {
                    graficoViewController.navigationItem.title = expression
                }
            default: break
            }
        }
    }
    
   override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "Graphic"{
            if expression == "" {
                graphicButton.backgroundColor = UIColor(red:200/235 ,green:225/255 ,blue:240/255 ,alpha:1.0 )
                return false
            }else{
                graphicButton.backgroundColor = UIColor(red:45/255 ,green:150/255 ,blue:100/255 ,alpha:1.0 )
            }
        }
        return true
    }
}

