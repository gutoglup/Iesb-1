//
//  GraphicView.swift
//  calculaitorBrainFinal
//
//  Created by leonardo on 10/04/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
protocol GraphDelegate: class {
    func requestY(toX: Double) -> Double
}

@IBDesignable
class GraphicView: UIView {
    
    weak var delegate: GraphDelegate?
    
    var origemGrafico: CGPoint? { didSet { setNeedsDisplay() } }
    @IBInspectable
    var scale: CGFloat = 1 { didSet{ setNeedsDisplay() } }
    @IBInspectable
    var colorStroke: UIColor = .cyan
    @IBInspectable
    var lineWidth: CGFloat = 1.0
    
    var centerOfGraph: CGPoint {
        if let origemGrafico = origemGrafico {
            return convert(origemGrafico, to: self)
        }
        return convert(center, to: self)
    }
    
    override func draw(_ rect: CGRect) {
        let linhaGrafico = UIBezierPath()
        
        var primeiroPonto = true
        
        for xValue in Int(bounds.minX)...Int(bounds.maxX) {
            if let originOfGraph = origemGrafico {
                
                let graphX = (Double(xValue)-Double(originOfGraph.x))/Double(scale)
                let yValue = self.delegate?.requestY(toX: graphX)
                let yPoint = originOfGraph.y - CGFloat(yValue!) * scale
                let point = CGPoint(x: CGFloat(xValue), y: CGFloat(yPoint))
                
                if primeiroPonto {
                    linhaGrafico.move(to: point)
                    primeiroPonto = false
                } else {
                    linhaGrafico.addLine(to: point)
                }
            }
            
        }
        colorStroke.setStroke()
        linhaGrafico.lineWidth = lineWidth
        linhaGrafico.stroke()
        
        let axesView = AxesDrawer(color: .blue, contentScaleFactor: scale)
        if let origemGrafico = origemGrafico {
            axesView.drawAxes(in: bounds, origin: origemGrafico, pointsPerUnit: scale)
        }
    }
    private func discoverCoordinateAxis(x: CGFloat, origin: CGPoint, scale: CGFloat) -> CGFloat {
        return (x - origin.x) / scale
    }
}
