//
//  CalculatorBrain.swift
//  calculaitorBrainFinal
//
//  Created by leonardo on 04/04/18.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

struct CalculatorBrain {
    var ultimaExpressao : ((Double) -> Double)?
    var accumulator: Double?
    
    var result : Double {
        get {
            return self.accumulator ?? 0
        }
    }
    
    private var pbo: PendingBinaryOperation?
    private enum Operation {
        case constant(Double)
        case unary((Double) -> Double)
        case binary((Double, Double) -> Double)
        case equals
    }
    
    // Dicionario de operações permitidas
    private var operations: [String: Operation] = [
        "π": Operation.constant(Double.pi),
        "e": Operation.constant(M_E),
        "√":Operation.unary({sqrt($0)}),
        "±": Operation.unary({-$0}),
        "x²": Operation.unary({$0*$0}),
        "sen": Operation.unary({sin($0)}),
        "cos": Operation.unary({cos($0)}),
        "tan": Operation.unary({tan($0)}),
        "*": Operation.binary({$0 * $1}),
        "+": Operation.binary({$0 + $1}),
        "-": Operation.binary({$0 - $1}),
        "÷": Operation.binary({$0 / $1}),
        "=": Operation.equals
        
    ]
    
    mutating func setOperand(_ operand: Double) {
        accumulator = operand
    }
    
    mutating func performOperation(_ mathematicalSymbol: String) {
        if let operation = operations[mathematicalSymbol] {
            switch operation {
            case .constant(let constant) :
                accumulator = constant
            case .unary(let function):
                if let accumulator = accumulator {
                    self.accumulator = function(accumulator)
                    ultimaExpressao = function
                }
            case .binary(let function): if let accumulator = accumulator {
                pbo = PendingBinaryOperation(firstOperand: accumulator, function: function)
                }
            case .equals: performPendingBinaryOperation()
            }
            
        }
    }
    
    private mutating func performPendingBinaryOperation() {
        if let accumulator = accumulator {
            self.accumulator = pbo?.perform(with: accumulator) ?? accumulator
        }
    }
    
    private struct PendingBinaryOperation {
        let firstOperand: Double
        let function: (Double, Double) -> Double
        
        func perform(with secondOperand: Double) -> Double {
            return function(firstOperand, secondOperand)
        }
    }
    
    public func isUnary(_ symbol: String) -> Bool {
        if let operation = operations[symbol] {
            switch operation {
            case .unary: return true
            default: break
            }
        }
        return false
    }
    
}
