//
//  GraphicViewController.swift
//  calculaitorBrainFinal
//
//  Created by leonardo on 04/04/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class GraphicViewController: UIViewController {
    
    var brainCalculator: CalculatorBrain?
    
    @IBOutlet weak var graphicView: GraphicView! {
        didSet{
            graphicView.delegate = self
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        graphicView.origemGrafico = CGPoint(x: graphicView.bounds.midX, y: graphicView.bounds.midY)
        graphicView.scale = 5
    }
    
    
    @IBAction func tapAction(_ sender: UITapGestureRecognizer) {
        switch sender.state {
        case .ended:
            graphicView.origemGrafico = sender.location(in: view)
        default: break
        }
    }
    @IBAction func pinchAction(_ sender: UIPinchGestureRecognizer) {
        if sender.state == .changed {
            graphicView.scale *= sender.scale
            sender.scale = 1
        }
    }
    @IBAction func painAction(_ sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .ended: fallthrough
        case .changed:
            let translation = sender.translation(in: graphicView)
            
            if graphicView.origemGrafico == nil {
                graphicView.origemGrafico = CGPoint(
                    x: graphicView.center.x + translation.x,
                    y: graphicView.center.y + translation.y)
            } else {
                graphicView.origemGrafico = CGPoint(
                    x: graphicView.origemGrafico!.x + translation.x,
                    y: graphicView.origemGrafico!.y + translation.y)
            }
            
            sender.setTranslation(CGPoint.zero, in: graphicView)
        default: break
        }
    }
}

extension GraphicViewController: GraphDelegate {
    func requestY(toX: Double) -> Double {
        if let ultimaExpressao = brainCalculator?.ultimaExpressao {
            return ultimaExpressao(toX)
        }
        return 0
    }
}
