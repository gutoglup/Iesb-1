//
//  User.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 09/05/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import CoreData

class User: NSManagedObject {
    
    static func insertOrUpdate( user: UserCodable, inContext context: NSManagedObjectContext) -> User? {
        let userById: NSFetchRequest<User> = self.fetchRequest()
        userById.predicate = NSPredicate(format: "id == %d", user.id)
        var persistentObject: User? = nil
        do {
            let result = try context.fetch(userById)
            if result.count > 1 {
                debugPrint("Inconsistência de dados detectada!!!")
                return nil
            }else {
                persistentObject = result.first ?? User(context: context)
            }
            
            persistentObject?.name = user.name
            persistentObject?.username = user.username
            persistentObject?.id = user.id
            
            try context.save()
        }catch let error as NSError {
            debugPrint("Erro ao utilizar o contexto: \(error)\nCom informações: \(error.userInfo)")
        }
        
        return persistentObject
    }
    
    static func get (context: NSManagedObject) {
        NSFetchRequest(entityName: <#T##String#>)
    }
}
