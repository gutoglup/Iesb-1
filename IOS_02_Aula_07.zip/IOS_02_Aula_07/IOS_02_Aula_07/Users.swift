//
//  User.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 02/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

struct UserCodable : Codable{
    var id: Int64
    var name: String
    var username: String
}
