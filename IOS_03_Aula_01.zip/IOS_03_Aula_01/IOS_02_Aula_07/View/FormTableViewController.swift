//
//  FormTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 09/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class FormTableViewController: UITableViewController {
    // Dados Pessoais
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var userNameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var phoneLabel: UITextField!
    @IBOutlet weak var websiteLabel: UITextField!
    // Endereço
    @IBOutlet weak var streetLabel: UITextField!
    @IBOutlet weak var suiteLabel: UITextField!
    @IBOutlet weak var cityLabel: UITextField!
    @IBOutlet weak var zipCodeLabel: UITextField!
    @IBOutlet weak var latLabel: UITextField!
    @IBOutlet weak var lngLabel: UITextField!
    // Compania
    @IBOutlet weak var nameCompanyLabel: UITextField!
    @IBOutlet weak var catchPhrase: UITextField!
    @IBOutlet weak var bsLabel: UITextField!
    
    var textFields: [UITextField] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textFields = [nameLabel,
         userNameLabel,
         emailLabel,
         streetLabel,
         suiteLabel,
         cityLabel,
         zipCodeLabel,
         latLabel,
         lngLabel,
         phoneLabel,
         websiteLabel,
         nameCompanyLabel,
         catchPhrase,
         bsLabel]
        
        textFields.forEach({$0.delegate = self})
        
    }
    @IBAction func salvarButton(_ sender: UIBarButtonItem?) {
        if verificarPreenchimento(doCampo: textFields) == true {
            let name = self.nameLabel.text!
            let username = self.userNameLabel.text!
            let email = self.emailLabel.text!
            let phone = self.phoneLabel.text!
            let website = self.websiteLabel.text!
            let street = self.streetLabel.text!
            let suite = self.suiteLabel.text!
            let city = self.cityLabel.text!
            let zipcode = self.zipCodeLabel.text!
            let lat = self.latLabel.text!
            let lng = self.lngLabel.text!
            let companyname = self.nameCompanyLabel.text!
            let catchPhrase = self.catchPhrase.text!
            let bs = self.bsLabel.text!
            
            let user : UserCodable = UserCodable(id: 101, name: name, username: username, email: email, phone: phone, website: website, address: CodableAddress(street: street, suite: suite, city: city, zipcode: zipcode, geo: CodableGeo(lat: lat, lng: lng)), company: CodableCompany(name: companyname, catchPhrase: catchPhrase, bs: bs))
 
            user.UploadUser(user: user)
            dismiss(animated: true, completion: nil)
            
        }
    }
    @IBAction func fecharModal(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    // Método que persiste dados em banco.
    private func persist(users: [UserCodable]) {
        AppDelegate.persistentContainer.performBackgroundTask { (context) in
            for user in users {
                guard User.insertOrUpdate(user: user, inContext: context) != nil else { break }
            }
        }
    }
    private func verificarPreenchimento(doCampo textFilds : [UITextField]) ->Bool {
        for textField in textFields{
            switch textField.keyboardType {
                case .emailAddress :
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.red.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
                case .URL:
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.blue.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
                default:
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.green.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
            }
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let segue.identifier = segue.identifier {
            if segue.identifier == "mapSegue" {
                if let destination = segue.destination as? MapViewController {
                    
                }
            }
        }
        
    }
}
extension FormTableViewController: UITextFieldDelegate, MapViewControllerDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        switch textField {
            case nameLabel: userNameLabel.becomeFirstResponder()
            case userNameLabel: emailLabel.becomeFirstResponder()
            case emailLabel: phoneLabel.becomeFirstResponder()
            case phoneLabel: websiteLabel.becomeFirstResponder()
            case websiteLabel: streetLabel.becomeFirstResponder()
            case streetLabel: suiteLabel.becomeFirstResponder()
            case suiteLabel: cityLabel.becomeFirstResponder()
            case cityLabel: zipCodeLabel.becomeFirstResponder()
            case zipCodeLabel: latLabel.becomeFirstResponder()
            case latLabel: lngLabel.becomeFirstResponder()
            case lngLabel: nameCompanyLabel.becomeFirstResponder()
            case nameCompanyLabel: catchPhrase.becomeFirstResponder()
            case catchPhrase: bsLabel.becomeFirstResponder()
            case bsLabel: self.salvarButton(nil)
            default: break
        }
        return true
    }
    
    func localizacaoSelecionada(coordenada: CLLocation) {
        
    }
}
