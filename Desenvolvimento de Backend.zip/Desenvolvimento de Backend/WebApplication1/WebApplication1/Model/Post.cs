﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Twitter.Model
{
    public class Post
    {
        public int Id_Post { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Date_Created { get; set; }
        public int Id_User { get; set; }
    }
}
