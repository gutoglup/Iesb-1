﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Twitter.Model;

namespace Twitter.Controllers
{
    [Route("twitterapi/[controller]")]
    public class PostController : Controller
    {

        private static List<Post> postList = new List<Post>();

        [HttpGet]
        public IEnumerable<Post> DoGet()
        {
            return postList;
        }

        [HttpPut("{id}")]
        public IActionResult DoPut(int id, [FromBody] Post post)
        {
            var item = postList.FirstOrDefault(t => t.Id_Post == id);

            if (item == null) { return NotFound(); }

            item.Title = post.Title;
            item.Description = post.Description;
            item.Date_Created = DateTime.Now;

            return new ObjectResult(item);


        }

        [HttpGet("{id}", Name = "GetTask")]
        public IActionResult DoGet(int id)
        {
            var item = postList.FirstOrDefault(t => t.Id_Post == id);

            if (item == null)
            {
                return NotFound();
            }

            return new ObjectResult(item);
        }

        [HttpPost]
        public IActionResult DoPost([FromBody] Post post)
        {
            if (post == null)
            {
                return BadRequest();
            }

            postList.Add(post);

            return CreatedAtRoute("GetTask", new { id = post.Id_Post }, post);
        }
        [HttpDelete("{id}")]
        public IActionResult DoDelete(int id)
        {
            var item = postList.FirstOrDefault(t => t.Id_Post == id);
            if (item == null) { return NotFound(); }
            postList.Remove(item);
            return Ok();
        }

    }
}