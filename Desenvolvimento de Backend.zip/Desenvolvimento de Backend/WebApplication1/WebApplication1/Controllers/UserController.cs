﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Twitter.Model;
using MySql.Data.MySqlClient;

namespace Twitter.Controllers
{
    [Route("twitterapi/[controller]")]
    public class UserController : Controller
    {
        public string ConnectionString { get; set; }
        private static List<User> userList = new List<User>();

        [HttpGet]
        public IEnumerable<User> DoGet()
        {
            return userList;
        }

        [HttpPut("{id}")]
        public IActionResult DoPut(int id, [FromBody] User user)
        {
            var item = userList.FirstOrDefault(t => t.Id_User == id);

            if (item == null) { return NotFound(); }

            item.Name = user.Name;
            item.IsActive = user.IsActive;

            return new ObjectResult(item);


        }

        [HttpGet("{id}", Name = "GetTask")]
        public IActionResult DoGet(int id)
        {
            var item = userList.FirstOrDefault(t => t.Id_User == id);

            if (item == null)
            {
                return NotFound();
            }

            return new ObjectResult(item);
        }

        [HttpPost]
        public IActionResult DoPost([FromBody] User user)
        {
            if (user == null)
            {
                return BadRequest();
            }

            userList.Add(user);

            return CreatedAtRoute("GetTask", new { id = user.Id_User }, user);
        }
        [HttpDelete("{id}")]
        public IActionResult DoDelete(int id)
        {
            var item = userList.FirstOrDefault(t => t.Id_User == id);
            if (item == null) { return NotFound(); }
            userList.Remove(item);
            return Ok();
        }

    }
}