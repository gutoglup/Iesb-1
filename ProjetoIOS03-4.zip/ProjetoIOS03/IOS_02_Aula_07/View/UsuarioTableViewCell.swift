//
//  UsuarioTableViewCell.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 02/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class UsuarioTableViewCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var username: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func config (user: UserCodable) {
        self.name.text = user.name
        self.username.text = user.username
    }
}
