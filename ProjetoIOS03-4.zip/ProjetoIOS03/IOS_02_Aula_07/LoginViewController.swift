//
//  LoginViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 06/06/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import FirebaseAuth

class LoginTableViewController: UITableViewController {
    
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var senhaLabel: UITextField!
    
    @IBAction func cadatrarComEmail(_ sender: UIButton) {
        if let email = emailLabel.text, let senha = senhaLabel.text {
            Auth.auth().signIn(withEmail: email, password: senha) { (user, error) in
                if user != nil{
                    print("deu certo")
                }
                if error != nil {
                    print(error)
                }
            }
        }
    }
}
