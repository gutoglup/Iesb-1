//
//  MasterTableViewController.swift
//  Aula06
//
//  Created by HC2MAC16 on 14/03/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class MasterTableViewController: UITableViewController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let index = indexPath.row
        
        var color = UIColor.black
        switch index {
            case 0: color = UIColor.black
            case 1: color = UIColor.red
            case 2: color = UIColor.green
            default: break
        }
        //remove a selecao da celula
        tableView.deselectRow(at: indexPath, animated: true)
        
        performSegue(withIdentifier: "detalheCor", sender: color)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detalheCor" {
            if let destination = segue.destination as? ViewController {
                destination.color = sender as? UIColor
            }
        }
    }

}
