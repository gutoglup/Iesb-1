//
//  ViewController.swift
//  Aula06
//
//  Created by HC2MAC16 on 14/03/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var color: UIColor? = UIColor.lightGray
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = color
    }


}

