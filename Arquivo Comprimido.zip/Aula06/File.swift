//
//  File.swift
//  Aula06
//
//  Created by HC2MAC16 on 14/03/18.
//  Copyright © 2018 LS. All rights reserved.
//

import Foundation

// criar split view controller
// implementar delegate splitViewController
// nao mecher com geometria no view didload
// viewWillAppear carregado a cada mudanda de tela
// ao sobre-escrever qualquer metodo do ciclo de vida da aplicacao
//override func viewDidLoad(){
//    super.viewDidLoad()
//}
// requisicao assincrona na viewWillAppear
// na animacao de rotacao nao chamar o super do metodo

// didReceiveMemoryWarning é chamado no maximo 3 vezes
// nao mecher no awakeFromNib
