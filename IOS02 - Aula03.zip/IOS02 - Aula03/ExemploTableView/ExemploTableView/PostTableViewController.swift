//
//  PostTableViewController.swift
//  ExemploTableView
//
//  Created by Pedro Henrique on 28/03/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import UIKit

class PostTableViewController: UITableViewController {
    
    var posts: [CodablePost]? {
        didSet {
            DispatchQueue.main.async(execute: tableView.reloadData)
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        PostLoader.loadPosts { [unowned self]  (posts, error) in
            self.posts = posts
            AppDelegate.persistentContainer.performBackgroundTask { (context) in
                //XGH - não fazer
                
                for codablePost in posts! {
                    let post = Post(context: context)
                    post.body = codablePost.body
                    post.title = codablePost.title
                    post.id = codablePost.id
                }
                do {
                    try context.save()
                }catch {
                    debugPrint(error)
                }
            }
        }
        
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celulaPost", for: indexPath) as! PostViewCell
        guard let post = posts?[indexPath.row] else { return cell }
        cell.configurar(comPost: post)
        return cell
    }

    

}
