//
//  Geo.swift
//  ExemploTableView
//
//  Created by Pedro Henrique on 04/04/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Geo: NSManagedObject {

}
