//
//  Post.swift
//  ExemploTableView
//
//  Created by Pedro Henrique on 04/04/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import CoreData

class Post: NSManagedObject {
    
    static func insertOrUpdate(_ post: CodablePost, inContext context: NSManagedObjectContext) -> Post {
        let postCoreData = Post(context: context)
        
        postCoreData.body = post.body
        postCoreData.title = post.title
        postCoreData.id = post.id
        
        return postCoreData
    }

}
