//
//  ViewController.swift
//  exemploTeclaodo
//
//  Created by HC2MAC16 on 21/03/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var bottonConstraint: NSLayoutConstraint!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(oTecladoApareceu(_:)), name: NSNotification.Name.UIKeyboardDidShow, object: view.window)
        
        NotificationCenter.default.addObserver(self, selector: #selector(oTecladoDesapareceu(_:)), name: NSNotification.Name.UIKeyboardDidHide, object: view.window)

    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func oTecladoApareceu(_ sender: Notification){
        // pegar tamanho do teclado
        if let frame = sender.userInfo?[UIKeyboardFrameEndUserInfoKey] as? CGRect {
            bottonConstraint.constant = bottonConstraint.constant + frame.size.height
        }
    }
    @objc private func oTecladoDesapareceu(_ sender: Notification){
        
    }
}

