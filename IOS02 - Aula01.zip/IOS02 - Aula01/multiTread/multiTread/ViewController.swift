//
//  ViewController.swift
//  multiTread
//
//  Created by HC2MAC16 on 21/03/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var load: UIActivityIndicatorView!
    
    let endereco = "https://www.planwallpaper.com/static/images/acede69a00dd92ffd13e1322d0e15d4b_large-hdwallpapers2016com.jpeg"
    var imagem : UIImage? {
        didSet{
            DispatchQueue.main.async(execute: exibirImagem)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let globalQueue = DispatchQueue.global(qos: .userInitiated)
        self.load.startAnimating()
        globalQueue.async(execute: baixarImagem)
        
    }
    private func exibirImagem(){
        guard let img = self.imagem else{ return }
        imageView.image = img
        self.load.stopAnimating()
    }
    private func baixarImagem(){
        if let url = URL(string: endereco){
            do {
                let data = try Data(contentsOf: url)
                imagem = UIImage(data: data)
            }catch{
                debugPrint(error)
            }
        }
        
    }
    
}

