//
//  postViewCell.swift
//  ExemploTableView
//
//  Created by HC2MAC16 on 28/03/18.
//  Copyright © 2018 IESB. All rights reserved.
//

import UIKit

class postViewCell: UITableViewCell {


    @IBOutlet weak var tituloCell: UILabel!
    @IBOutlet weak var conteudoTextoCell: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configurarCells(comPost post: Post){
        tituloCell.text = post.title
        conteudoTextoCell.text = post.body
    }

}
