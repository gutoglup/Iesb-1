//
//  User.swift
//  IOS_02_Aula_07
//
//  Created by leonardo on 09/05/18.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit
import CoreData

class User: NSManagedObject {
    
    static func insertOrUpdate( user: UserCodable, inContext context: NSManagedObjectContext) -> User? {
        let userById: NSFetchRequest<User> = self.fetchRequest()
        userById.predicate = NSPredicate(format: "id == %d", user.id)
        var persistentObject: User? = nil
        do {
            let result = try context.fetch(userById)
            if result.count > 1 {
                debugPrint("Inconsistência de dados detectada!!!")
                return nil
            }else {
                persistentObject = result.first ?? User(context: context)
            }
            
            let address = Address.insertOrUpdate(user.address, inContext: context)
            let company = Company.insertOrUpdate(user.company, inContext: context)
            
            persistentObject?.id = user.id
            persistentObject?.name = user.name
            persistentObject?.username = user.username
            persistentObject?.email = user.email
            persistentObject?.phone = user.phone
            persistentObject?.website = user.website
            persistentObject?.address = address
            persistentObject?.company = company
            
            try context.save()
        }catch let error as NSError {
            debugPrint("Erro ao utilizar o contexto: \(error)\nCom informações: \(error.userInfo)")
        }
        
        return persistentObject
    }
    static func get(context: NSManagedObjectContext) -> [User]? {
        let users: NSFetchRequest<User> = self.fetchRequest()
        do {
            let result = try context.fetch(users)
            return result
        } catch {
            print(error)
        }
        return nil
        
    }
}
