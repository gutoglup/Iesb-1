//
//  FormTableViewController.swift
//  IOS_02_Aula_07
//
//  Created by HC2MAC16 on 09/05/2018.
//  Copyright © 2018 LS. All rights reserved.
//

import UIKit

class FormTableViewController: UITableViewController {
    @IBOutlet weak var nameLabel: UITextField!
    @IBOutlet weak var userNameLabel: UITextField!
    @IBOutlet weak var emailLabel: UITextField!
    @IBOutlet weak var streetLabel: UITextField!
    @IBOutlet weak var suiteLabel: UITextField!
    @IBOutlet weak var cityLabel: UITextField!
    @IBOutlet weak var zipCodeLabel: UITextField!
    @IBOutlet weak var latLabel: UITextField!
    @IBOutlet weak var lngLabel: UITextField!
    @IBOutlet weak var phoneLabel: UITextField!
    @IBOutlet weak var websiteLabel: UITextField!
    @IBOutlet weak var nameCompanyLabel: UITextField!
    @IBOutlet weak var catchPhrase: UITextField!
    @IBOutlet weak var bsLabel: UITextField!
    
    var textFields: [UITextField] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textFields = [nameLabel,
         userNameLabel,
         emailLabel,
         streetLabel,
         suiteLabel,
         cityLabel,
         zipCodeLabel,
         latLabel,
         lngLabel,
         phoneLabel,
         websiteLabel,
         nameCompanyLabel,
         catchPhrase,
         bsLabel]
        
        textFields.forEach({$0.delegate = self})
        
    }
    @IBAction func salvarButton(_ sender: UIBarButtonItem) {
        if verificarPreenchimento(doCampo: textFields) == true {
            print("salvou")
        }
    }
    @IBAction func fecharModal(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    func enviar(){
        
    }
    // Método que persiste dados em banco.
    private func persist(users: [UserCodable]) {
        AppDelegate.persistentContainer.performBackgroundTask { (context) in
            for user in users {
                guard User.insertOrUpdate(user: user, inContext: context) != nil else { break }
            }
        }
    }
    private func postUser() {
       
    }
    private func converterParaUserCodable() -> UserCodable{
        var user : UserCodable
        var geo: CodableGeo
        var address: CodableAddress
        var company: CodableCompany
        user.name = self.nameLabel.text!
        user.username = self.userNameLabel.text!
        user.email = self.emailLabel.text!
        user.phone = self.phoneLabel.text!
        user.website = self.websiteLabel.text!
        
        address.street = self.streetLabel.text!
        address.suite = self.suiteLabel.text!
        address.city = self.cityLabel.text!
        address.zipcode = self.zipCodeLabel.text!
        geo.lat = self.latLabel.text!
        geo.lng = self.lngLabel.text!
        
        company.name = self.nameCompanyLabel.text!
        company.catchPhrase = self.catchPhrase.text!
        company.bs = self.bsLabel.text!


        address.geo = geo
        user.address = address
        user.company = company
        
        return user
    }
    private func verificarPreenchimento(doCampo textFilds : [UITextField]) ->Bool {
        for textField in textFields{
            switch textField.keyboardType {
                case .emailAddress :
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.red.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
                case .URL:
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.blue.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
                default:
                    if textField.text == ""{
                        textField.layer.borderWidth = 1
                        textField.layer.borderColor = UIColor.green.cgColor
                        textField.becomeFirstResponder()
                        return false
                    } else {
                        textField.layer.borderWidth = 0.25
                        textField.layer.borderColor = UIColor.lightGray.cgColor
                    }
            }
        }
        return true
    }
}
extension FormTableViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        switch textField {
            case nameLabel: userNameLabel.becomeFirstResponder()
            case userNameLabel: emailLabel.becomeFirstResponder()
            case emailLabel: phoneLabel.becomeFirstResponder()
            case phoneLabel: websiteLabel.becomeFirstResponder()
            case websiteLabel: streetLabel.becomeFirstResponder()
            case streetLabel: suiteLabel.becomeFirstResponder()
            case suiteLabel: cityLabel.becomeFirstResponder()
            case cityLabel: zipCodeLabel.becomeFirstResponder()
            case zipCodeLabel: latLabel.becomeFirstResponder()
            case latLabel: lngLabel.becomeFirstResponder()
            case lngLabel: nameCompanyLabel.becomeFirstResponder()
            case nameCompanyLabel: catchPhrase.becomeFirstResponder()
            case catchPhrase: bsLabel.becomeFirstResponder()
            case bsLabel: enviar()
            default: break
        }
        return true
    }
}
